--=================== CLASE PELOTA ===================
-- Encapsula TODOS los datos y el comportamiento de la pelota:
-- posición/física (body, forma, fixture), imagen, movimiento y salto.
Pelota = {}
Pelota.__index = Pelota

-- Constructor: crea una pelota nueva dentro del "world" de física,
-- ubicada inicialmente en (x, y)
function Pelota.new(world, x, y)
    local self = setmetatable({}, Pelota)

    -- Guardamos la posición inicial para poder reiniciar la pelota (tecla "r")
    self.posicionInicialX = x
    self.posicionInicialY = y

    -- Dimensiones y velocidad de movimiento
    self.ancho = 175 * 0.40
    self.alto = 184 * 0.40
    self.radio = self.ancho * 0.4 -- mismo radio de colisión que usaba el proyecto original
    self.velocidad = 300

    -- Estado del salto (se cargaba antes en la tabla global "salto")
    self.salto = {
        inicial = 0,
        fuerza = 300,
        limite = 400,
    }
    self.enElSuelo = false

    -- Cuerpo físico (love.physics / Box2D)
    self.body = love.physics.newBody(world, x, y, "dynamic")
    self.forma = love.physics.newCircleShape(self.radio)
    self.fixture = love.physics.newFixture(self.body, self.forma, 1)
    self.fixture:setRestitution(0.7)
    self.fixture:setFriction(5)
    self.body:setAngularDamping(2.5)

    -- Imagen de la pelota (Assets/Pelota.png)
    self.imagen = love.graphics.newImage("Assets/Pelota.png")
    -- La imagen tiene bastante margen transparente alrededor del dibujo real;
    -- estos valores ubican el centro y diámetro reales de la pelota dentro
    -- del archivo, para que el sprite quede bien centrado sobre el cuerpo físico.
    self.imgOrigenX = 742.5
    self.imgOrigenY = 460
    self.imgDiametro = 524.5
    self.escala = (self.radio * 2) / self.imgDiametro

    return self
end

-- ============ Getters / setters (envuelven al "body" físico) ============
function Pelota:getX()
    return self.body:getX()
end

function Pelota:getY()
    return self.body:getY()
end

function Pelota:getLinearVelocity()
    return self.body:getLinearVelocity()
end

function Pelota:setLinearVelocity(vx, vy)
    self.body:setLinearVelocity(vx, vy)
end

function Pelota:applyLinearImpulse(ix, iy)
    self.body:applyLinearImpulse(ix, iy)
end

function Pelota:setPosition(x, y)
    self.body:setPosition(x, y)
end

function Pelota:setEnElSuelo(valor)
    self.enElSuelo = valor
end

function Pelota:estaEnElSuelo()
    return self.enElSuelo
end

-- Vuelve a poner la pelota en su posición inicial y frena su movimiento
function Pelota:reiniciar()
    self:setPosition(self.posicionInicialX, self.posicionInicialY)
    self.body:setLinearVelocity(0, 0)
    self.salto.inicial = 0
end

-- ============ Lógica propia de la pelota (input del jugador) ============
function Pelota:actualizar(dt)
    -- Cargar y soltar el salto mientras está apoyada en el suelo
    if self.enElSuelo then
        if love.mouse.isDown(1) or love.keyboard.isDown("space") then
            if self.salto.inicial < self.salto.limite then
                self.salto.inicial = self.salto.inicial + (self.salto.fuerza * dt)
            else
                self.salto.inicial = self.salto.limite
            end
        else
            if self.salto.inicial > 0 then
                self:applyLinearImpulse(0, -self.salto.inicial)
                self.salto.inicial = 0
            end
        end
    end

    -- Reiniciar posición y puntaje
    if love.keyboard.isDown("r") then
        self:reiniciar()
        puntaje = 0
        tiempo = 120
    end

    -- Movimiento horizontal
    local vx, vy = self:getLinearVelocity()
    if love.keyboard.isDown("left", "a") then
        self:setLinearVelocity(-self.velocidad, vy)
    elseif love.keyboard.isDown("right", "d") then
        self:setLinearVelocity(self.velocidad, vy)
    end
end

-- ============ Dibujo ============
function Pelota:dibujar()
    love.graphics.draw(
        self.imagen,
        self:getX(), self:getY(),
        self.body:getAngle(),
        self.escala, self.escala,
        self.imgOrigenX, self.imgOrigenY
    )
end
